package com.delaroystudios.alarmreminder;

public class MTodo {

        String id,tdname,isselect,cattype;

    public MTodo() {
    }

    public MTodo(String id, String tdname, String isselect, String cattype) {
        this.id = id;
        this.tdname = tdname;
        this.isselect = isselect;
        this.cattype = cattype;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTdname() {
        return tdname;
    }

    public void setTdname(String tdname) {
        this.tdname = tdname;
    }

    public String getIsselect() {
        return isselect;
    }

    public void setIsselect(String isselect) {
        this.isselect = isselect;
    }

    public String getCattype() {
        return cattype;
    }

    public void setCattype(String cattype) {
        this.cattype = cattype;
    }
}
