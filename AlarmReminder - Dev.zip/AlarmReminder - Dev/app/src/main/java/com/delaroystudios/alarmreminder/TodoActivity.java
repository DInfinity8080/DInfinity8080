package com.delaroystudios.alarmreminder;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.delaroystudios.alarmreminder.adapter.SearchAdapter;
import com.delaroystudios.alarmreminder.adapter.TodoRvadapter;
import com.delaroystudios.alarmreminder.adapter.Todoadapter;
import com.delaroystudios.alarmreminder.data.AlarmReminderDbHelper;

import java.util.ArrayList;

public class TodoActivity extends AppCompatActivity {
    Todoadapter mCursorAdapter;

    EditText ettodo;
    Button btnadd;
    private Toolbar mToolbar;
  //  ListView reminderListView;

    RecyclerView rvtodo;
    ArrayList<MTodo> mTodoArrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo);

        ettodo = (EditText) findViewById(R.id.ettodo);
        btnadd = (Button) findViewById(R.id.btnadd);

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        mToolbar.setTitle("Todo Activity");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        final String typecat = getIntent().getStringExtra("cat");

      /*  reminderListView = (ListView) findViewById(R.id.list);
        View emptyView = findViewById(R.id.empty_view);
        reminderListView.setEmptyView(emptyView);

        AlarmReminderDbHelper o = new AlarmReminderDbHelper(TodoActivity.this);
        final Cursor c = o.gettodo(typecat);


        mCursorAdapter = new Todoadapter(TodoActivity.this, c,typecat);
        reminderListView.setAdapter(mCursorAdapter);
*/
      rvtodo = (RecyclerView) findViewById(R.id.rvtodo);
        buildRecyclerView();
        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if(ettodo.getText().toString().trim().equalsIgnoreCase(""))
                {
                    ettodo.setError("Enter Todo");

                }
                else {
                    AlarmReminderDbHelper db = new AlarmReminderDbHelper(TodoActivity.this);
                    db.addTodo(ettodo.getText().toString(),"0",typecat);
                    AlarmReminderDbHelper o = new AlarmReminderDbHelper(TodoActivity.this);
                  /*  final Cursor cc = o.gettodo(typecat);

                    mCursorAdapter.changeCursor(cc);
                    mCursorAdapter.notifyDataSetChanged();*/
                    mTodoArrayList.clear();
                    mTodoArrayList = o.gettododata(typecat);
                    TodoRvadapter adapter = new TodoRvadapter(mTodoArrayList,
                            TodoActivity.this,null,typecat);
                    // adding layout manager to our recycler view.
                    LinearLayoutManager manager = new LinearLayoutManager(TodoActivity.this);
                    rvtodo.setHasFixedSize(true);
                    rvtodo.setLayoutManager(manager);
                    rvtodo.setAdapter(adapter);
                    ettodo.setText("");
                }

            }
        });

    }


    private void buildRecyclerView() {

        // below line we are creating a new array list
        mTodoArrayList = new ArrayList<>();

        AlarmReminderDbHelper db = new AlarmReminderDbHelper(TodoActivity.this);
        final String typecat = getIntent().getStringExtra("cat");

        mTodoArrayList = db.gettododata(typecat);

      //  Toast.makeText(getApplicationContext(),String.valueOf(mTodoArrayList.size()),Toast.LENGTH_SHORT).show();

        TodoRvadapter adapter = new TodoRvadapter(mTodoArrayList,
                TodoActivity.this,null,typecat);
        // adding layout manager to our recycler view.
        LinearLayoutManager manager = new LinearLayoutManager(this);
        rvtodo.setHasFixedSize(true);
        rvtodo.setLayoutManager(manager);
        rvtodo.setAdapter(adapter);
    }

}
