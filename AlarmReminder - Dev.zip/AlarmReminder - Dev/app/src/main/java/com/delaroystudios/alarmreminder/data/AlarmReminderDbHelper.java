package com.delaroystudios.alarmreminder.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.delaroystudios.alarmreminder.MAlarm;
import com.delaroystudios.alarmreminder.MListType;
import com.delaroystudios.alarmreminder.MReminder;
import com.delaroystudios.alarmreminder.MTodo;

import java.util.ArrayList;


public class AlarmReminderDbHelper extends SQLiteOpenHelper {

    String atype = "BirthDay";
    private static final String DATABASE_NAME = "alarmreminder.db";

    private static final int DATABASE_VERSION = 1;

    public AlarmReminderDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        // Create a String that contains the SQL statement to create the reminder table
        String SQL_CREATE_ALARM_TABLE = "CREATE TABLE " + AlarmReminderContract.AlarmReminderEntry.TABLE_NAME + " ("
                + AlarmReminderContract.AlarmReminderEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + AlarmReminderContract.AlarmReminderEntry.KEY_TITLE + " TEXT NOT NULL, "
                + AlarmReminderContract.AlarmReminderEntry.KEY_TYPE + " TEXT NOT NULL, "
                + AlarmReminderContract.AlarmReminderEntry.KEY_DATE + " TEXT NOT NULL, "
                + AlarmReminderContract.AlarmReminderEntry.KEY_TIME + " TEXT NOT NULL, "
                + AlarmReminderContract.AlarmReminderEntry.KEY_REPEAT + " TEXT NOT NULL, "
                + AlarmReminderContract.AlarmReminderEntry.KEY_REPEAT_NO + " TEXT NOT NULL, "
                + AlarmReminderContract.AlarmReminderEntry.KEY_REPEAT_TYPE + " TEXT NOT NULL, "
                + AlarmReminderContract.AlarmReminderEntry.KEY_ACTIVE + " TEXT NOT NULL " + " );";

        // Execute the SQL statement
        sqLiteDatabase.execSQL(SQL_CREATE_ALARM_TABLE);

        String query = "CREATE TABLE " + AlarmReminderContract.AlarmReminderEntry.TABLE_NAME2 + " ("
                + AlarmReminderContract.AlarmReminderEntry.T_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + AlarmReminderContract.AlarmReminderEntry.T_TODONAME + " TEXT,"
                + AlarmReminderContract.AlarmReminderEntry.T_ISSLECT + " TEXT,"
                + AlarmReminderContract.AlarmReminderEntry.T_TYPE + " TEXT)";

        // at last we are calling a exec sql
        // method to execute above sql query
        sqLiteDatabase.execSQL(query);

        String listtable = "CREATE TABLE " + AlarmReminderContract.AlarmReminderEntry.TABLE_NAME3 + " ("
                + AlarmReminderContract.AlarmReminderEntry.L_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + AlarmReminderContract.AlarmReminderEntry.L_LISTTYPE + " TEXT,"
                + AlarmReminderContract.AlarmReminderEntry.L_IMGNO + " TEXT)";

        // at last we are calling a exec sql
        // method to execute above sql query
        sqLiteDatabase.execSQL(listtable);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }


    public ArrayList<MAlarm> getBd() {
        ArrayList<MAlarm> returnList = new ArrayList<>();
        String queryString = "SELECT * FROM remindertodo WHERE type='BirthDay'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);
        if (cursor.moveToFirst()) {
            do {
                MAlarm m = new MAlarm();
                m.setId(cursor.getString(0));
                m.setTitle(cursor.getString(1));
                returnList.add(m);
            } while (cursor.moveToNext());
        } else {

        }

        cursor.close();
        db.close();
        return returnList;
    }

    public Cursor getBcur() {
        ArrayList<MAlarm> returnList = new ArrayList<>();
        String queryString = "SELECT * FROM remindertodo WHERE type='BirthDay'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);
        return cursor;
    }

    public Cursor getAcur() {
        ArrayList<MAlarm> returnList = new ArrayList<>();
        String queryString = "SELECT * FROM remindertodo WHERE type='Anniversary'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);
        return cursor;
    }

    public void addTodo(String name, String isselect, String typecat) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(AlarmReminderContract.AlarmReminderEntry.T_TODONAME, name);
        values.put(AlarmReminderContract.AlarmReminderEntry.T_ISSLECT, isselect);
        values.put(AlarmReminderContract.AlarmReminderEntry.T_TYPE, typecat);

        db.insert(AlarmReminderContract.AlarmReminderEntry.TABLE_NAME2, null, values);
        db.close();
    }

    public Cursor gettodo(String typecat) {
        String cattype = typecat;
        String[] columns = {"_id", "tdname", "isselect", "cattype"};
        // String queryString = "SELECT * FROM todolist WHERE cattype +'='+"+typecat;
        SQLiteDatabase db = this.getReadableDatabase();
        // Cursor cursor = db.rawQuery(queryString, null);

        Cursor cursor = db.query("todolist", columns, "cattype=?", new String[]{cattype}, null, null, null);

        return cursor;
    }

    public boolean delTodo(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        return db.delete(AlarmReminderContract.AlarmReminderEntry.TABLE_NAME2,
                AlarmReminderContract.AlarmReminderEntry.T_ID + "=" + id, null) > 0;
    }

    public int getAllreminderCount() {
        String countQuery = "SELECT  * FROM " + AlarmReminderContract.AlarmReminderEntry.TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }

    public int getAnniversaryCount() {
        String countQuery = "SELECT * FROM remindertodo WHERE type='Anniversary'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }

    public int getBirthdayCount() {
        String countQuery = "SELECT * FROM remindertodo WHERE type='BirthDay'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }

    public ArrayList<MReminder> getallrem() {
        ArrayList<MReminder> returnList = new ArrayList<>();
        String queryString = "SELECT * FROM remindertodo ORDER BY date ASC";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);
        if (cursor.moveToFirst()) {
            do {
                MReminder m = new MReminder();
                m.setId(cursor.getString(0));
                m.setTitle(cursor.getString(1));
                m.setType(cursor.getString(2));
                m.setDate(cursor.getString(3));
                m.setTime(cursor.getString(4));
                m.setRepeat(cursor.getString(5));
                m.setRepeatno(cursor.getString(6));
                m.setRepeattype(cursor.getString(7));
                m.setActive(cursor.getString(8));

                returnList.add(m);
            } while (cursor.moveToNext());

        }
        return returnList;
    }

    public ArrayList<MTodo> gettododata(String typecat) {
        ArrayList<MTodo> returnList = new ArrayList<>();

        String cattype = typecat;
        String[] columns = {"_id", "tdname", "isselect", "cattype"};
        // String queryString = "SELECT * FROM todolist WHERE cattype +'='+"+typecat;
        SQLiteDatabase db = this.getReadableDatabase();
        // Cursor cursor = db.rawQuery(queryString, null);

        Cursor cursor = db.query("todolist", columns, "cattype=?", new String[]{cattype}, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                MTodo m = new MTodo();
                m.setId(cursor.getString(0));
                m.setTdname(cursor.getString(1));
                m.setIsselect(cursor.getString(2));
                m.setCattype(cursor.getString(3));


                returnList.add(m);
            } while (cursor.moveToNext());

        }
        return returnList;
    }


    public void addListtype(String name, String ino) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(AlarmReminderContract.AlarmReminderEntry.L_LISTTYPE, name);
        values.put(AlarmReminderContract.AlarmReminderEntry.L_IMGNO, ino);
        db.insert(AlarmReminderContract.AlarmReminderEntry.TABLE_NAME3, null, values);
        db.close();
    }

    public ArrayList<MListType> getalltypes() {
        ArrayList<MListType> returnList = new ArrayList<>();
        String queryString = "SELECT * FROM listtype";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);
        if (cursor.moveToFirst()) {
            do {
                MListType m = new MListType();
                m.setId(cursor.getString(0));
                m.setLname(cursor.getString(1));
                m.setIno(cursor.getString(2));

                returnList.add(m);
            } while (cursor.moveToNext());

        }
        return returnList;
    }


    public boolean removeList(MListType m) {

        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(AlarmReminderContract.AlarmReminderEntry.TABLE_NAME2, "cattype=?", new String[]{m.getLname().trim()});


        return db.delete(AlarmReminderContract.AlarmReminderEntry.TABLE_NAME3,
                AlarmReminderContract.AlarmReminderEntry.T_ID + "=" + m.getId(), null) > 0;


    }

    private boolean removetodos(String cattype) {
        SQLiteDatabase db = this.getWritableDatabase();


        return db.delete(AlarmReminderContract.AlarmReminderEntry.TABLE_NAME2,
                AlarmReminderContract.AlarmReminderEntry.T_TYPE + "=" + cattype, null) > 0;

    }

    public boolean updatechk(int id, String s) {

        SQLiteDatabase mDb= this.getWritableDatabase();
        ContentValues args = new ContentValues();
        args.put(AlarmReminderContract.AlarmReminderEntry.T_ID, id);
        args.put(AlarmReminderContract.AlarmReminderEntry.T_ISSLECT, s);
        return mDb.update(AlarmReminderContract.AlarmReminderEntry.TABLE_NAME2, args, AlarmReminderContract.AlarmReminderEntry.T_ID + "=" + id, null)>0;

    }
}




