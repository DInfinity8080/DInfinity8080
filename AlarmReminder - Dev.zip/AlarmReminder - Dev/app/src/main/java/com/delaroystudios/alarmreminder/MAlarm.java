package com.delaroystudios.alarmreminder;

public class MAlarm {

    String id,title,type,date,time,repeat,repeat_no,repeat_type,active;


    public MAlarm() {
    }

    public MAlarm(String id, String title, String type, String date,
                  String time, String repeat, String repeat_no, String repeat_type, String active) {
        this.id = id;
        this.title = title;
        this.type = type;
        this.date = date;
        this.time = time;
        this.repeat = repeat;
        this.repeat_no = repeat_no;
        this.repeat_type = repeat_type;
        this.active = active;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getRepeat() {
        return repeat;
    }

    public void setRepeat(String repeat) {
        this.repeat = repeat;
    }

    public String getRepeat_no() {
        return repeat_no;
    }

    public void setRepeat_no(String repeat_no) {
        this.repeat_no = repeat_no;
    }

    public String getRepeat_type() {
        return repeat_type;
    }

    public void setRepeat_type(String repeat_type) {
        this.repeat_type = repeat_type;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }
}
