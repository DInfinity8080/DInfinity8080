package com.delaroystudios.alarmreminder;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.delaroystudios.alarmreminder.adapter.SearchAdapter;
import com.delaroystudios.alarmreminder.data.AlarmReminderContract;
import com.delaroystudios.alarmreminder.data.AlarmReminderDbHelper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

public class Home extends AppCompatActivity {


    RecyclerView rvalarm;
    private SearchAdapter adapter;
    private ArrayList<MReminder> alarmArrayList;

    ArrayList<MReminder> aldates;
    TextView btnadrem, btntodo;

    String tableString;
    TextView tval;
    TextView tbd, tvanni, tvalcount, tvbdcount, tvanicount,tvlisttodo;
    SearchView actionSearch;
    TextView tvt1, tvt2, tvt3, tvuc1, tvuc2, tvuc3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        aldates = new ArrayList<>();
        actionSearch = (SearchView) findViewById(R.id.actionSearch);
        rvalarm = (RecyclerView) findViewById(R.id.rvalarm);
        buildRecyclerView();

       /* ArrayList<MAlarm> al= new ArrayList<>();
        AlarmReminderDbHelper o = new AlarmReminderDbHelper(Home.this);
        al = o.getBd();

        for (MAlarm a:al)
        {
            System.out.println("title "+a.getTitle());
            Toast.makeText(getApplicationContext(),"title"+a.getTitle(),Toast.LENGTH_SHORT).show();
        }*/


       actionSearch.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
           @Override
           public boolean onQueryTextSubmit(String s) {
               return false;
           }

           @Override
           public boolean onQueryTextChange(String newText) {

               if (newText.equalsIgnoreCase(""))
               {
                  rvalarm.setVisibility(View.GONE);
               }
               else
               {
                   filter(newText);

               }
               return false;
           }
       });

       actionSearch.setOnCloseListener(new SearchView.OnCloseListener() {
           @Override
           public boolean onClose() {
               rvalarm.setVisibility(View.GONE);
               //Toast.makeText(getApplicationContext(),"Close",Toast.LENGTH_SHORT).show();
               return false;
           }
       });

        AlarmReminderDbHelper db = new AlarmReminderDbHelper(Home.this);
        int allcount = db.getAllreminderCount();
        int anicount = db.getAnniversaryCount();
        int bdcount = db.getBirthdayCount();


        //  Toast.makeText(getApplicationContext(),"All"+String.valueOf(allcount)+"ani:"+anicount+"bd:"+anibd,Toast.LENGTH_SHORT).show();

        btnadrem = (TextView) findViewById(R.id.btnaddnewrem);
        btntodo = (TextView) findViewById(R.id.btntodo);

        tval = (TextView) findViewById(R.id.tvallrem);
        tbd = (TextView) findViewById(R.id.tvbdrem);
        tvanni = (TextView) findViewById(R.id.tvanireminders);

        tvt1 = (TextView) findViewById(R.id.tvt1);
        tvt2 = (TextView) findViewById(R.id.tvt2);
        tvt3 = (TextView) findViewById(R.id.tvt3);

        tvuc1 = (TextView) findViewById(R.id.tvuc1);
        tvuc2 = (TextView) findViewById(R.id.tvuc2);
        tvuc3 = (TextView) findViewById(R.id.tvuc3);

        tvalcount = (TextView) findViewById(R.id.tvallcount);
        tvbdcount = (TextView) findViewById(R.id.tvbdcount);
        tvanicount = (TextView) findViewById(R.id.tvanicount);

        tvlisttodo = (TextView) findViewById(R.id.todolist);

        tvalcount.setText(String.valueOf(allcount) + "   ");
        tvbdcount.setText(String.valueOf(bdcount) + "   ");
        tvanicount.setText(String.valueOf(anicount) + "   ");

        tvt1.setVisibility(View.GONE);
        tvuc1.setVisibility(View.GONE);
        tvt2.setVisibility(View.GONE);
        tvuc2.setVisibility(View.GONE);
        tvt3.setVisibility(View.GONE);
        tvuc3.setVisibility(View.GONE);

        tvlisttodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Listtypes.class));
                finish();            }
        });

        btnadrem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(), AddReminderActivity.class));

            }
        });
        btntodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(), Addlistpage.class));
            }
        });

        tval.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                finish();
            }
        });

        tbd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(), BirthdayReminder.class));
                finish();
            }
        });

        tvanni.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(), AnnivReminders.class));
                finish();
            }
        });


        ArrayList<MReminder> al = db.getallrem();

        HashMap<Integer,Integer> dateindex = new HashMap<>();
        int size = al.size();

        int count= 0;

        for (int i = 0; i < al.size(); i++) {

            String day = getdays(al.get(i).getDate());
            if(Integer.parseInt(day)>=0)
            {
              aldates.add(al.get(i));

              dateindex.put(Integer.parseInt(day),count);
              count++;

            }

        }

        TreeMap<Integer,Integer> tm=new  TreeMap<Integer,Integer> (dateindex);

       ArrayList<Integer> alindex = new ArrayList<>();

        Iterator itr=tm.keySet().iterator();
        while(itr.hasNext())
        {
            int key=(int)itr.next();
            System.out.println("Days:  "+key+"     Index:   "+dateindex.get(key));
            alindex.add(dateindex.get(key));
        }



        for (int i=0;i<aldates.size();i++)
        {

            if (i == 0) {
                MReminder mr1 = aldates.get(alindex.get(0));
                tvt1.setText(mr1.getTitle());

                String days1 = getdays(mr1.getDate());
                tvuc1.setText(days1 + " days to go");
                tvt1.setVisibility(View.VISIBLE);
                tvuc1.setVisibility(View.VISIBLE);


            } else if (i == 1) {

                MReminder mr1 = aldates.get(alindex.get(0));
                tvt1.setText(mr1.getTitle());

                String days1 = getdays(mr1.getDate());
                tvuc1.setText(days1 + " days to go");
                MReminder mr2 = aldates.get(alindex.get(1));
                tvt2.setText(mr2.getTitle());
                String days2 = getdays(mr2.getDate());
                tvuc2.setText(days2 + " days to go");

                tvt1.setVisibility(View.VISIBLE);
                tvuc1.setVisibility(View.VISIBLE);
                tvt2.setVisibility(View.VISIBLE);
                tvuc2.setVisibility(View.VISIBLE);



            } else if (i == 2) {

                MReminder mr1 = aldates.get(alindex.get(0));
                tvt1.setText(mr1.getTitle());

                String days1 = getdays(mr1.getDate());
                tvuc1.setText(days1 + " days to go");
                MReminder mr2 = aldates.get(alindex.get(1));
                tvt2.setText(mr2.getTitle());
                String days2 = getdays(mr2.getDate());
                tvuc2.setText(days2 + " days to go");

                MReminder mr3 = aldates.get(alindex.get(2));
                tvt3.setText(mr3.getTitle());
                String days3 = getdays(mr3.getDate());
                tvuc3.setText(days3 + " days to go");

                tvt1.setVisibility(View.VISIBLE);
                tvuc1.setVisibility(View.VISIBLE);
                tvt2.setVisibility(View.VISIBLE);
                tvuc2.setVisibility(View.VISIBLE);
                tvt3.setVisibility(View.VISIBLE);
                tvuc3.setVisibility(View.VISIBLE);

            } else {
            }

        }

        try {


        } catch (NullPointerException e) {
            Log.d("error", e.getMessage());
        }
          /*  for (MReminder m:al)
            {
                SimpleDateFormat myFormat = new SimpleDateFormat("d/M/yyyy");
                String inputString1 = m.getDate();
                String inputString2 = "1/3/2022";


                try {
                    Date date1 = myFormat.parse(inputString1);
                    Date date2 = myFormat.parse(inputString2);
                    long diff = date1.getTime() - date2.getTime();
                   Log.d ("Days: " , String.valueOf(TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS)));


                   tvt1.setText(m.getTitle());
                   tvuc1.setText(String.valueOf(TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS)));

                } catch (ParseException e) {
                    e.printStackTrace();
                }


            }*/




    }


    private String getdays(String date) {
        Date todaydate = new Date();
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(todaydate);
        int tyear = calendar.get(Calendar.YEAR);




        SimpleDateFormat myFormat = new SimpleDateFormat("d/M/yyyy");
        String inputString1 = date;

        String acyear = inputString1.substring(inputString1.length() - 4);

        int acyr = Integer.parseInt(acyear);

        if(acyr <tyear)
        {
            StringBuffer sb = new StringBuffer(inputString1);
            sb.setLength(sb.length()-4);
            sb.append(String.valueOf(tyear));
            inputString1 =String.valueOf(sb);
        }


        String inputString2 = myFormat.format(todaydate);


        System.out.println("Adate:"+inputString1+" Tdate"+todaydate);

        String days = "";

        try {
            Date date1 = myFormat.parse(inputString1);
            Date date2 = myFormat.parse(inputString2);
            long diff = date1.getTime() - date2.getTime();
            Log.d("Days: ", String.valueOf(TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS)));
            days = String.valueOf(TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS));

        } catch (ParseException e) {
            e.printStackTrace();
        }

        return days;
    }

    private void getdate(Cursor allRows) {
        if (allRows.moveToFirst()) {
            String[] columnNames = allRows.getColumnNames();
            do {
                for (String name : columnNames) {
                    tableString += String.format("%s: %s\n", name,
                            allRows.getString(allRows.getColumnIndex(name)));
                    Log.d("check", tableString);

                }


            } while (allRows.moveToNext());

            Log.d("check", tableString);
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                startActivity(new Intent(getApplicationContext(),Home.class));
                break;
        }
        return true;
    }

    private void filter(String text) {
        // creating a new array list to filter our data.
        ArrayList<MReminder> filteredlist = new ArrayList<>();

        // running a for loop to compare elements.
        for (MReminder item : alarmArrayList) {
            // checking if the entered string matched with any item of our recycler view.
            if (item.getTitle().toLowerCase().contains(text.toLowerCase())) {
                // if the item is matched we are
                // adding it to our filtered list.
                filteredlist.add(item);
                rvalarm.setVisibility(View.VISIBLE);
            }
        }
        if (filteredlist.isEmpty()) {
            // if no item is added in filtered list we are
            // displaying a toast message as no data found.
            rvalarm.setVisibility(View.GONE);

            Toast.makeText(this, "No Data Found..", Toast.LENGTH_SHORT).show();
        }

        else {
            // at last we are passing that filtered
            // list to our adapter class.
            adapter.filterList(filteredlist);
        }
    }

    private void buildRecyclerView() {

        // below line we are creating a new array list
        alarmArrayList = new ArrayList<>();

        AlarmReminderDbHelper db = new AlarmReminderDbHelper(Home.this);

        alarmArrayList = db.getallrem();


        adapter = new SearchAdapter(alarmArrayList, Home.this,rvalarm);

        // adding layout manager to our recycler view.
        LinearLayoutManager manager = new LinearLayoutManager(this);
        rvalarm.setHasFixedSize(true);
        rvalarm.setLayoutManager(manager);
        rvalarm.setAdapter(adapter);
    }

}
