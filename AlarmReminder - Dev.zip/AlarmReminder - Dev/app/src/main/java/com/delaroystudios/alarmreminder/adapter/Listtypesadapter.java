package com.delaroystudios.alarmreminder.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.delaroystudios.alarmreminder.Addlistpage;
import com.delaroystudios.alarmreminder.MListType;
import com.delaroystudios.alarmreminder.R;
import com.delaroystudios.alarmreminder.TodoActivity;
import com.delaroystudios.alarmreminder.data.AlarmReminderDbHelper;

import java.util.ArrayList;

public class Listtypesadapter extends RecyclerView.Adapter<Listtypesadapter.VH> {

    Context context;
    ArrayList<MListType> alListTypes;
    AlertDialog.Builder builder;


    public Listtypesadapter(Context context, ArrayList<MListType> alListTypes) {
        this.context = context;
        this.alListTypes = alListTypes;
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.cardtypes, parent, false);
        return new VH(listItem);    }

    @Override
    public void onBindViewHolder(VH holder, final int position) {

        final MListType m = alListTypes.get(position);

        holder.tvname.setText(m.getLname());
        int drawableResourceId = context.getResources().getIdentifier(m.getIno(), "drawable", context.getPackageName());

        holder.ivicon.setImageResource(drawableResourceId);

        holder.ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                context.startActivity(new Intent(context, TodoActivity.class).putExtra("cat",m.getLname()));
            }
        });


        holder.ll.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                builder = new AlertDialog.Builder(context);


                builder.setMessage("Do you want to Delete?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                             MListType m = alListTypes.get(position);
                                AlarmReminderDbHelper db = new AlarmReminderDbHelper(context);
                                if (db.removeList(m))
                                {
                                    alListTypes.remove(position);
                                    notifyItemRemoved(position);
                                    notifyItemRangeChanged(position, alListTypes.size());


                                }
                                else
                                {
                                    Toast.makeText(context,"Error",Toast.LENGTH_SHORT).show();
                                }
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();

                            }
                        });

                AlertDialog alert = builder.create();

                alert.show();



                return false;
            }
        });
    }

    @Override
    public int getItemCount() {
        return alListTypes.size();
    }

    public static class VH extends RecyclerView.ViewHolder {

        LinearLayout ll;
        TextView tvname;
        ImageView ivicon;

        public VH(View itemView) {
            super(itemView);

            ll = (LinearLayout) itemView.findViewById(R.id.llcard);
            tvname = (TextView) itemView.findViewById(R.id.tvlisttype);
            ivicon = (ImageView) itemView.findViewById(R.id.ivimg);
        }
    }
}
