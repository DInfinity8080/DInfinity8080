package com.delaroystudios.alarmreminder.adapter;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Paint;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import com.delaroystudios.alarmreminder.MTodo;
import com.delaroystudios.alarmreminder.R;
import com.delaroystudios.alarmreminder.data.AlarmReminderContract;
import com.delaroystudios.alarmreminder.data.AlarmReminderDbHelper;

import java.util.ArrayList;

public class TodoRvadapter extends RecyclerView.Adapter<TodoRvadapter.VH> {

    Cursor c;
    String catype;
    ArrayList<MTodo> todoArrayList;
    Context context;

    public TodoRvadapter(ArrayList<MTodo> todoArrayList, Context context, Cursor c, String catype) {
        this.todoArrayList = todoArrayList;
        this.context = context;
        this.c = c;
        this.catype = catype;
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardlist, parent, false);
        return new VH(view);
    }

    @Override
    public void onBindViewHolder(final VH holder, final int position) {
        final AlarmReminderDbHelper db = new AlarmReminderDbHelper(context);

        final MTodo m = todoArrayList.get(position);

        holder.mTitleText.setText(m.getTdname());

        if (m.getIsselect().equalsIgnoreCase("1")) {
            holder.mTitleText.setPaintFlags(Paint.STRIKE_THRU_TEXT_FLAG);
            holder.chk.setChecked(true);
        } else {
            holder.chk.setChecked(false);
            holder.mTitleText.setPaintFlags(0);
        }


        holder.btnremove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                int id = Integer.parseInt(m.getId());

                AlarmReminderDbHelper db = new AlarmReminderDbHelper(context);

                if (db.delTodo(id)) {

                    todoArrayList.remove(position);
                    notifyItemRemoved(position);


                } else {
                    Toast.makeText(context, "Error", Toast.LENGTH_SHORT).show();
                }

            }
        });


        holder.chk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (m.getIsselect().equalsIgnoreCase("1")) {

                    db.updatechk(Integer.parseInt(m.getId()), "0");
                   // Toast.makeText(context, "Update 0", Toast.LENGTH_SHORT).show();
                    updtelist(position, "0");


                } else {
                    db.updatechk(Integer.parseInt(m.getId()), "1");
                  //  Toast.makeText(context, "Update 1", Toast.LENGTH_SHORT).show();
                    updtelist(position, "1");

                }

            }
        });

    }

    private void updtelist(int position, String s) {
        MTodo m = todoArrayList.get(position);
        m.setIsselect(s);
        notifyItemChanged(position);
    }


    @Override
    public int getItemCount() {
        return todoArrayList.size();
    }

    public static class VH extends RecyclerView.ViewHolder {


        TextView mTitleText;
        CheckBox chk;
        Button btnremove;

        public VH(View itemView) {
            super(itemView);
            mTitleText = (TextView) itemView.findViewById(R.id.tvname);
            chk = (CheckBox) itemView.findViewById(R.id.chk1);
            btnremove = (Button) itemView.findViewById(R.id.btndelete);


        }
    }
}
