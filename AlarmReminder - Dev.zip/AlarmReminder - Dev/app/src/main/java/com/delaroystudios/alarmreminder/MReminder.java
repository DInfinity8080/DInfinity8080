package com.delaroystudios.alarmreminder;

public class MReminder {

    String id,title,type,date,time,repeat,repeatno,repeattype,active;

    public MReminder() {
    }


    public MReminder(String id,String title, String type, String date,
                     String time, String repeat, String repeatno, String repeattype, String active) {
        this.id = id;

        this.title = title;
        this.type = type;
        this.date = date;
        this.time = time;
        this.repeat = repeat;
        this.repeatno = repeatno;
        this.repeattype = repeattype;
        this.active = active;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getRepeat() {
        return repeat;
    }

    public void setRepeat(String repeat) {
        this.repeat = repeat;
    }

    public String getRepeatno() {
        return repeatno;
    }

    public void setRepeatno(String repeatno) {
        this.repeatno = repeatno;
    }

    public String getRepeattype() {
        return repeattype;
    }

    public void setRepeattype(String repeattype) {
        this.repeattype = repeattype;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }
}
