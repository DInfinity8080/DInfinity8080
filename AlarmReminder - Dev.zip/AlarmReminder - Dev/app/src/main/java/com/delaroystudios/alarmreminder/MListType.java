package com.delaroystudios.alarmreminder;

public class MListType {

    String id,lname,ino;


    public MListType() {
    }

    public MListType(String id, String lname, String ino) {
        this.id = id;
        this.lname = lname;
        this.ino = ino;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getIno() {
        return ino;
    }

    public void setIno(String ino) {
        this.ino = ino;
    }
}
