package com.delaroystudios.alarmreminder.adapter;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;
import com.delaroystudios.alarmreminder.R;
import com.delaroystudios.alarmreminder.TodoActivity;
import com.delaroystudios.alarmreminder.data.AlarmReminderContract;
import com.delaroystudios.alarmreminder.data.AlarmReminderDbHelper;

public class Todoadapter extends CursorAdapter {

    private TextView mTitleText;
    CheckBox chk;
    Button btnremove;
    Cursor c;
    Context context;
    String catype;

    public Todoadapter(Context context, Cursor c,String catype) {
        super(context,c);
        this.context = context;
        this.c = c;
        this.catype=catype;
    }
    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {


        return LayoutInflater.from(context).inflate(R.layout.cardlist, parent, false);



    }

    @Override
    public void bindView(View view, final Context context, final Cursor cursor) {



        mTitleText = (TextView) view.findViewById(R.id.tvname);
        chk = (CheckBox) view.findViewById(R.id.chk1);
        btnremove = (Button) view.findViewById(R.id.btndelete);

        int nameindex = cursor.getColumnIndex(AlarmReminderContract.AlarmReminderEntry.T_TODONAME);
        int isselectindex = cursor.getColumnIndex(AlarmReminderContract.AlarmReminderEntry.T_ISSLECT);

        String name = cursor.getString(nameindex);
        String isselect = cursor.getString(isselectindex);





        int x = Integer.parseInt(isselect);
        boolean bool = false;
        if(x == 1)
        {
            bool = true;
        }


        mTitleText.setText(name);


        //chk.setChecked(bool);



        btnremove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                 int idindex = cursor.getColumnIndex(AlarmReminderContract.AlarmReminderEntry.T_ID);

                    int id = cursor.getInt(idindex);

                AlarmReminderDbHelper db = new AlarmReminderDbHelper(context);

                if(db.delTodo(id))
                {
                     final Cursor cc = db.gettodo(catype);

                    changeCursor(cc);
                    notifyDataSetChanged();
                }
                else {
                    Toast.makeText(context,"Error",Toast.LENGTH_SHORT).show();
                }

            }
        });







    }




}
