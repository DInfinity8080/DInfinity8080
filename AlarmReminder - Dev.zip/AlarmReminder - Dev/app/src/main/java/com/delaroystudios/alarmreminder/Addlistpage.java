package com.delaroystudios.alarmreminder;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.delaroystudios.alarmreminder.data.AlarmReminderDbHelper;

public class Addlistpage extends AppCompatActivity {
    EditText etlist;
    ImageView i1, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11, i12, i13, i14, i15, listicon;
    Button btnaddlist;
    Toolbar mToolbar;
    String ino = "i1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addlistpage);


        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        mToolbar.setTitle("Add List");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);


        i1 = (ImageView) findViewById(R.id.i1);
        i2 = (ImageView) findViewById(R.id.i2);
        i3 = (ImageView) findViewById(R.id.i3);
        i4 = (ImageView) findViewById(R.id.i4);
        i5 = (ImageView) findViewById(R.id.i5);
        i6 = (ImageView) findViewById(R.id.i6);
        i7 = (ImageView) findViewById(R.id.i7);
        i8 = (ImageView) findViewById(R.id.i8);
        i9 = (ImageView) findViewById(R.id.i9);
        i10 = (ImageView) findViewById(R.id.i10);
        i11 = (ImageView) findViewById(R.id.i11);
        i12 = (ImageView) findViewById(R.id.i12);
        i13 = (ImageView) findViewById(R.id.i13);
        i14 = (ImageView) findViewById(R.id.i14);
        i15 = (ImageView) findViewById(R.id.i15);
        listicon = (ImageView) findViewById(R.id.iconaddlist);

        etlist = (EditText) findViewById(R.id.listname);
        btnaddlist = (Button) findViewById(R.id.btnaddlist);


        btnaddlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (etlist.getText().toString().trim().matches("")) {
                    etlist.setError("Enter List Name");
                } else {

                    AlarmReminderDbHelper db = new AlarmReminderDbHelper(Addlistpage.this);
                    db.addListtype(etlist.getText().toString(), ino);
                    Toast.makeText(getApplicationContext(), "List Added", Toast.LENGTH_SHORT).show();
                    etlist.setText("");
                    startActivity(new Intent(getApplicationContext(),Listtypes.class));
                }
            }
        });


        i1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                listicon.setImageResource(R.drawable.i1);
                ino = "i1";

            }
        });

        i2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                listicon.setImageResource(R.drawable.i2);
                ino = "i2";


            }
        });

        i3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                listicon.setImageResource(R.drawable.i3);
                ino = "i3";


            }
        });


        i4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                listicon.setImageResource(R.drawable.i4);
                ino = "i4";


            }
        });

        i5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                listicon.setImageResource(R.drawable.i5);
                ino = "i5";


            }
        });

        i6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                listicon.setImageResource(R.drawable.i6);
                ino = "i6";


            }
        });
        i7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                listicon.setImageResource(R.drawable.i7);
                ino = "i7";


            }
        });
        i8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                listicon.setImageResource(R.drawable.i8);
                ino = "i8";


            }
        });


        i9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                listicon.setImageResource(R.drawable.i9);
                ino = "i9";


            }
        });


        i10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                listicon.setImageResource(R.drawable.i10);
                ino = "i10";


            }
        });

        i11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                listicon.setImageResource(R.drawable.i11);
                ino = "i11";


            }
        });

        i12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                listicon.setImageResource(R.drawable.i12);
                ino = "i12";


            }
        });

        i13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                listicon.setImageResource(R.drawable.i13);
                ino = "i13";


            }
        });


        i14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                listicon.setImageResource(R.drawable.i14);
                ino = "i14";


            }
        });

        i15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                listicon.setImageResource(R.drawable.i15);
                ino = "i15";


            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        startActivity(new Intent(getApplicationContext(), Home.class));


    }


}
