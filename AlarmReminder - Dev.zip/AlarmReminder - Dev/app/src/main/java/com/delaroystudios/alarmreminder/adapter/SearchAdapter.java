package com.delaroystudios.alarmreminder.adapter;

import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;
import com.delaroystudios.alarmreminder.AddReminderActivity;
import com.delaroystudios.alarmreminder.BirthdayReminder;
import com.delaroystudios.alarmreminder.MAlarm;
import com.delaroystudios.alarmreminder.MReminder;
import com.delaroystudios.alarmreminder.R;
import com.delaroystudios.alarmreminder.data.AlarmReminderContract;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.ViewHolder> {


    private ArrayList<MReminder> alarmsModalArrayList;
    private Context context;
    private ColorGenerator mColorGenerator = ColorGenerator.DEFAULT;
    private TextDrawable mDrawableBuilder;
    RecyclerView rvalarm;
    public SearchAdapter(ArrayList<MReminder> alarmsModalArrayList, Context context,RecyclerView rvalarm) {
        this.alarmsModalArrayList = alarmsModalArrayList;
        this.context = context;
        this.rvalarm = rvalarm;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.alarm_items, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        final MReminder m = alarmsModalArrayList.get(position);
        holder.mTitleText.setText(m.getTitle());
        holder.mDateAndTimeText.setText(m.getDate()+ " " + m.getTime());

        String type = m.getType();
        if(type.equalsIgnoreCase("BirthDay"))
        {
            int age = getAge(m.getDate());
            holder.mtype.setText(String.valueOf(age));


            String letter = "A";

            if(type != null && !type.isEmpty()) {
                letter = type.substring(0, 1);
            }

            int color = mColorGenerator.getRandomColor();

            // Create a circular icon consisting of  a random background colour and first letter of title
            mDrawableBuilder = TextDrawable.builder()
                    .buildRound(letter, color);
            holder.mThumbnailImage.setImageDrawable(mDrawableBuilder);
        }
        else
        {
            holder.mtype.setText(type);

            String letter = "A";

            if(type != null && !type.isEmpty()) {
                letter = type.substring(0, 1);
            }

            int color = mColorGenerator.getRandomColor();

            // Create a circular icon consisting of  a random background colour and first letter of title
            mDrawableBuilder = TextDrawable.builder()
                    .buildRound(letter, color);
            holder.mThumbnailImage.setImageDrawable(mDrawableBuilder);
        }

        setActiveImage(m.getActive(),holder.mActiveImage);
        setReminderRepeatInfo(m.getRepeat(), m.getRepeatno(), m.getRepeattype(),holder.mRepeatInfoText);

        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent = new Intent(context, AddReminderActivity.class);

                Uri currentVehicleUri = ContentUris.withAppendedId(AlarmReminderContract.AlarmReminderEntry.CONTENT_URI, Long.parseLong(m.getId()));

                // Set the URI on the data field of the intent
                intent.setData(currentVehicleUri);

                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return alarmsModalArrayList.size();
    }

    public void filterList(ArrayList<MReminder> filterllist) {

        alarmsModalArrayList = filterllist;

        notifyDataSetChanged();
    }
    public static class ViewHolder extends RecyclerView.ViewHolder {

         TextView mTitleText, mDateAndTimeText, mRepeatInfoText,mtype;
         ImageView mActiveImage , mThumbnailImage;
         RelativeLayout card;

        public ViewHolder(View itemView) {
            super(itemView);

            mTitleText = (TextView) itemView.findViewById(R.id.recycle_title);
            mtype = (TextView) itemView.findViewById(R.id.recycle_type);
            mDateAndTimeText = (TextView) itemView.findViewById(R.id.recycle_date_time);
            mRepeatInfoText = (TextView) itemView.findViewById(R.id.recycle_repeat_info);
            mActiveImage = (ImageView) itemView.findViewById(R.id.active_image);
            mThumbnailImage = (ImageView) itemView.findViewById(R.id.thumbnail_image);
            card = (RelativeLayout) itemView.findViewById(R.id.carddata);

        }
    }


    private int getAge(String dobString){

        Date date = null;
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        try {
            date = sdf.parse(dobString);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        if(date == null) return 0;

        Calendar dob = Calendar.getInstance();
        Calendar today = Calendar.getInstance();

        dob.setTime(date);

        int year = dob.get(Calendar.YEAR);
        int month = dob.get(Calendar.MONTH);
        int day = dob.get(Calendar.DAY_OF_MONTH);

        dob.set(year, month+1, day);

        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);

        if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)){
            age--;
        }



        return age;
    }

    public void setActiveImage(String active,ImageView mActiveImage){
        if(active.equals("true")){
            mActiveImage.setImageResource(R.drawable.ic_notifications_on_white_24dp);
        }else if (active.equals("false")) {
            mActiveImage.setImageResource(R.drawable.ic_notifications_off_grey600_24dp);
        }
    }

    public void setReminderRepeatInfo(String repeat, String repeatNo, String repeatType,TextView mRepeatInfoText) {
        if(repeat.equals("true")){
            mRepeatInfoText.setText("Every " + repeatNo + " " + repeatType + "(s)");
        }else if (repeat.equals("false")) {
            mRepeatInfoText.setText("Repeat Off");
        }
    }
}
